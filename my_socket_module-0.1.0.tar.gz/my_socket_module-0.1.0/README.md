# My Socket Module

A Python module for a simple socket-based client-server interaction.

## Installation

```bash
pip install my_socket_module
